import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PendaftaranScreen extends StatelessWidget {
  final Map<String, String> beasiswa;

  PendaftaranScreen(this.beasiswa);

  final DatabaseReference database = FirebaseDatabase.instance.ref();

  void daftarBeasiswa(BuildContext context) async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      PendaftaranBeasiswa pendaftaran = PendaftaranBeasiswa(
        userId: user.uid,
        fakultas: beasiswa['fakultas']!,
        tingkat: beasiswa['tingkat']!,
        lokasi: beasiswa['lokasi']!,
        deskripsi: beasiswa['deskripsi']!,
        persyaratan: beasiswa['persyaratan']!,
        caraDaftar: beasiswa['cara_daftar']!,
      );

      await database.child('pendaftaran_beasiswa').push().set(pendaftaran.toJson());
      await database.child('users/${user.uid}/pendaftaran').push().set(pendaftaran.toJson());

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Pendaftaran Berhasil')));
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Anda harus login terlebih dahulu')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pendaftaran Beasiswa'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Container(
          padding: EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Fakultas: ${beasiswa['fakultas']}'),
              Text('Tingkat: ${beasiswa['tingkat']}'),
              Text('Lokasi: ${beasiswa['lokasi']}'),
              Text('Deskripsi: ${beasiswa['deskripsi']}'),
              Text('Persyaratan: ${beasiswa['persyaratan']}'),
              Text('Cara Daftar: ${beasiswa['cara_daftar']}'),
              SizedBox(height: 20),
              Align(
                alignment: Alignment.center,
                child: ElevatedButton(
                  onPressed: () => daftarBeasiswa(context),
                  child: Text('Daftar'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PendaftaranBeasiswa {
  String userId;
  String fakultas;
  String tingkat;
  String lokasi;
  String deskripsi;
  String persyaratan;
  String caraDaftar;

  PendaftaranBeasiswa({
    required this.userId,
    required this.fakultas,
    required this.tingkat,
    required this.lokasi,
    required this.deskripsi,
    required this.persyaratan,
    required this.caraDaftar,
  });

  Map<String, dynamic> toJson() {
    return {
      'userId': userId,
      'fakultas': fakultas,
      'tingkat': tingkat,
      'lokasi': lokasi,
      'deskripsi': deskripsi,
      'persyaratan': persyaratan,
      'caraDaftar': caraDaftar,
    };
  }
}
