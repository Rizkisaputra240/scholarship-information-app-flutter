import 'package:apk/screen/profil.dart';
import 'package:flutter/material.dart';
import 'pendaftaran_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Beasiswa'),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Beasiswa'),
              Tab(text: 'Profil'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            BeasiswaScreen(),
            ProfileScreen(),
          ],
        ),
      ),
    );
  }
}

class BeasiswaScreen extends StatelessWidget {
  final List<Map<String, String>> beasiswaList = [
    {
      'fakultas': 'Teknik',
      'tingkat': 'S1',
      'lokasi': 'Jakarta',
      'deskripsi': 'Beasiswa Teknik untuk S1 di Jakarta',
      'persyaratan': 'IPK minimal 3.5, Aktif organisasi',
      'cara_daftar': 'Daftar melalui website resmi',
    },
    {
      'fakultas': 'Ekonomi',
      'tingkat': 'S2',
      'lokasi': 'Bandung',
      'deskripsi': 'Beasiswa Ekonomi untuk S2 di Bandung',
      'persyaratan': 'IPK minimal 3.75, TOEFL 550',
      'cara_daftar': 'Kirim berkas ke email beasiswa',
    },
    {
      'fakultas': 'Hukum',
      'tingkat': 'S1',
      'lokasi': 'Surabaya',
      'deskripsi': 'Beasiswa Hukum untuk S1 di Surabaya',
      'persyaratan': 'IPK minimal 3.6, Aktif organisasi',
      'cara_daftar': 'Daftar melalui website resmi',
    },
    {
      'fakultas': 'Kedokteran',
      'tingkat': 'S1',
      'lokasi': 'Yogyakarta',
      'deskripsi': 'Beasiswa Kedokteran untuk S1 di Yogyakarta',
      'persyaratan': 'IPK minimal 3.8, TOEFL 500',
      'cara_daftar': 'Kirim berkas ke email beasiswa',
    },
    {
      'fakultas': 'Ilmu Komputer',
      'tingkat': 'S2',
      'lokasi': 'Malang',
      'deskripsi': 'Beasiswa Ilmu Komputer untuk S2 di Malang',
      'persyaratan': 'IPK minimal 3.7, TOEFL 550',
      'cara_daftar': 'Daftar melalui website resmi',
    },
    // Tambahkan lebih banyak beasiswa sesuai kebutuhan
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        FilterWidget(),
        Expanded(
          child: ListView.builder(
            itemCount: beasiswaList.length,
            itemBuilder: (ctx, index) {
              return BeasiswaItem(
                beasiswaList[index],
                () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => BeasiswaDetailScreen(beasiswaList[index]),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class BeasiswaItem extends StatelessWidget {
  final Map<String, String> beasiswa;
  final VoidCallback onTap;

  BeasiswaItem(this.beasiswa, this.onTap);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      child: ListTile(
        title: Text(beasiswa['fakultas']!),
        subtitle: Text('${beasiswa['tingkat']} - ${beasiswa['lokasi']}'),
        onTap: onTap,
      ),
    );
  }
}

class FilterWidget extends StatefulWidget {
  @override
  _FilterWidgetState createState() => _FilterWidgetState();
}

class _FilterWidgetState extends State<FilterWidget> {
  String selectedFakultas = 'Semua';
  String selectedTingkat = 'Semua';
  String selectedLokasi = 'Semua';

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            DropdownButton<String>(
              value: selectedFakultas,
              items: ['Semua', 'Teknik', 'Ekonomi']
                  .map((fakultas) => DropdownMenuItem(
                        child: Text(fakultas),
                        value: fakultas,
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  selectedFakultas = value!;
                });
              },
            ),
            DropdownButton<String>(
              value: selectedTingkat,
              items: ['Semua', 'S1', 'S2']
                  .map((tingkat) => DropdownMenuItem(
                        child: Text(tingkat),
                        value: tingkat,
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  selectedTingkat = value!;
                });
              },
            ),
            DropdownButton<String>(
              value: selectedLokasi,
              items: ['Semua', 'Jakarta', 'Bandung']
                  .map((lokasi) => DropdownMenuItem(
                        child: Text(lokasi),
                        value: lokasi,
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  selectedLokasi = value!;
                });
              },
            ),
          ],
        ),
      ],
    );
  }
}

class BeasiswaDetailScreen extends StatelessWidget {
  final Map<String, String> beasiswa;

  BeasiswaDetailScreen(this.beasiswa);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Beasiswa'),
        automaticallyImplyLeading: false, // Remove back button
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Container(
          padding: EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                beasiswa['deskripsi']!,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text('Persyaratan:', style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              Text(beasiswa['persyaratan']!),
              SizedBox(height: 16),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => PendaftaranScreen(beasiswa),
                    ),
                  );
                },
                child: Text('Daftar Beasiswa'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
