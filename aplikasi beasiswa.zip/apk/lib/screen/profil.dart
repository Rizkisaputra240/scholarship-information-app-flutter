import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'loginpage.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _isLoading = true;
  String? userEmail;
  String? userUid;
  String? userName;
  String? userSchool;
  String? userPhoneNumber;
  List<Map<String, dynamic>> userPendaftaran = [];

  @override
  void initState() {
    super.initState();
    fetchData().then((_) {
      setState(() {
        _isLoading = false;
      });
    });
  }

  Future<void> fetchData() async {
    try {
      User? user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        userEmail = user.email;
        userUid = user.uid;

        final ref = FirebaseDatabase.instance.ref('users/$userUid');
        final snapshot = await ref.get();

        if (snapshot.exists) {
          final data = Map<String, dynamic>.from(snapshot.value as Map);
          userName = data['name'];
          userSchool = data['school'];
          userPhoneNumber = data['phoneNumber'];
        }

        final pendaftaranRef = FirebaseDatabase.instance.ref('users/$userUid/pendaftaran');
        final pendaftaranSnapshot = await pendaftaranRef.get();

        if (pendaftaranSnapshot.exists) {
          final pendaftaranData = Map<String, dynamic>.from(pendaftaranSnapshot.value as Map);
          userPendaftaran = pendaftaranData.values.map((e) => Map<String, dynamic>.from(e as Map)).toList();
        }
      }
    } catch (e) {
      print('Error fetching user data: $e');
    }
  }

  Future<void> logout() async {
    try {
      await FirebaseAuth.instance.signOut();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => HalamanLogin()),
      );
    } catch (e) {
      print('Error logging out: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
        actions: [
          IconButton(
            icon: Icon(Icons.person),
            onPressed: () {
              // Handle action
            },
          ),
        ],
      ),
      body: _isLoading
          ? Center(
              child: CircularProgressIndicator(),
            )
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: ListView(
                children: [
                  Container(
                    padding: EdgeInsets.all(16.0),
                    margin: EdgeInsets.only(bottom: 16.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ListTile(
                          leading: Icon(Icons.person, color: Colors.blue), // Email icon
                          title: Text(
                            'Nama Lengkap:',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(userName ?? ''),
                        ),
                        ListTile(
                          leading: Icon(Icons.email, color: Colors.blue), // Email icon
                          title: Text(
                            'Email:',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(userEmail ?? ''),
                        ),
                        ListTile(
                          leading: Icon(Icons.confirmation_number, color: Colors.blue), // UID icon
                          title: Text(
                            'UID:',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(userUid ?? ''),
                        ),
                        ListTile(
                          leading: Icon(Icons.school, color: Colors.blue), // School icon
                          title: Text(
                            'Asal Sekolah:',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(userSchool ?? ''),
                        ),
                        ListTile(
                          leading: Icon(Icons.phone, color: Colors.blue), // Phone icon
                          title: Text(
                            'Nomor Telepon:',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(userPhoneNumber ?? ''),
                        ),
                        SizedBox(height: 16),
                        Text(
                          'Beasiswa yang Didaftar:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        ...userPendaftaran.map((pendaftaran) {
                          return ListTile(
                            title: Text(pendaftaran['fakultas']),
                            subtitle: Text('${pendaftaran['tingkat']} - ${pendaftaran['lokasi']}'),
                          );
                        }).toList(),
                      ],
                    ),
                  ),
                  
                  ElevatedButton(
                    onPressed: logout,
                    child: Text('Logout'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      padding: EdgeInsets.symmetric(horizontal: 50, vertical: 20),
                      textStyle: TextStyle(fontSize: 16),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: ProfileScreen(),
    theme: ThemeData(
      primarySwatch: Colors.blue,
    ),
  ));
}
