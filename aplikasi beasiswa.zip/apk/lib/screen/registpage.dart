import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'loginpage.dart';

class HalamanRegister extends StatefulWidget {
  const HalamanRegister({Key? key}) : super(key: key);

  @override
  State<HalamanRegister> createState() => _HalamanRegisterState();
}

class _HalamanRegisterState extends State<HalamanRegister> {
  TextEditingController _email = TextEditingController();
  TextEditingController _name = TextEditingController();
  TextEditingController _pass = TextEditingController();
  TextEditingController _school = TextEditingController();
  TextEditingController _phoneNumber = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  "Buat Akun",
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _email,
                  decoration: InputDecoration(
                    hintText: "Email",
                    icon: Icon(Icons.person),
                  ),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _name,
                  decoration: InputDecoration(
                    hintText: "Nama Lengkap",
                    icon: Icon(Icons.badge),
                  ),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _school,
                  decoration: InputDecoration(
                    hintText: "Asal Sekolah",
                    icon: Icon(Icons.school),
                  ),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _phoneNumber,
                  decoration: InputDecoration(
                    hintText: "Nomor Telepon",
                    icon: Icon(Icons.phone),
                  ),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _pass,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: "Password",
                    icon: Icon(Icons.lock),
                  ),
                ),
                const SizedBox(height: 30),
                ElevatedButton(
                  onPressed: () {
                    registration();
                  },
                  child: const Text("Daftar"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> registration() async {
    if (_email.text.isEmpty || _name.text.isEmpty || _pass.text.isEmpty || _school.text.isEmpty || _phoneNumber.text.isEmpty) {
      Get.snackbar("Error", "Semua kolom harus diisi");
      return;
    }

    try {
      UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _email.text,
        password: _pass.text,
      );

      User? user = userCredential.user;
      if (user != null) {
        final ref = FirebaseDatabase.instance.ref('users/${user.uid}');
        await ref.set({
          'email': _email.text,
          'name': _name.text,
          'school': _school.text,
          'phoneNumber': _phoneNumber.text,
        });

        Get.snackbar("Success", "Pendaftaran berhasil");
        Get.to(() => HalamanLogin());
      }
    } catch (e) {
      Get.snackbar("Error", "Terjadi kesalahan saat pendaftaran: $e");
    }
  }
}
